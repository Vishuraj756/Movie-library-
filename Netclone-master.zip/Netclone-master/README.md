# Netclone
Cloned the Home page of Netflix using HTML, CSS , Javascript and BootStrap.

                                  😃Hit that ⭐ button to show some ❤️
